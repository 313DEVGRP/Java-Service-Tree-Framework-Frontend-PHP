<?php
if(strpos($_SERVER['SCRIPT_NAME'], "theme")===false) {
    include_once('../../../common.php');
} else {
    include_once('../../../../../common.php');
}